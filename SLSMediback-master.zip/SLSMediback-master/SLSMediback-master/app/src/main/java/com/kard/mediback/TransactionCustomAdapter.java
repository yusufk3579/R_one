package com.kard.mediback;


import android.content.Context;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class TransactionCustomAdapter extends ArrayAdapter<TransactionDataModel>{

    private ArrayList<TransactionDataModel> dataSet;
    Context mContext;
    AlertDialog.Builder alert;
    LayoutInflater inflater;
    View alertLayout;

    // View lookup cache
    private static class ViewHolder {
        TextView txtProductName;
        TextView txtAmount;
        ImageView icon;
    }

    public TransactionCustomAdapter(ArrayList<TransactionDataModel> data, Context context) {
        super(context, R.layout.transaction_listview, data);
        this.dataSet = data;
        this.mContext=context;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        //we need to get the view of the xml for our list item
        //And for this we need a layoutinflater
        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        //getting the view
        View view = layoutInflater.inflate(R.layout.transaction_listview, null, false);

        //getting the view elements of the list from the view
        ImageView imageView = view.findViewById(R.id.add_remove_icon);
        TextView textViewName = view.findViewById(R.id.product_name);
        TextView textViewCost = view.findViewById(R.id.product_cost);

        //getting the hero of the specified position
        TransactionDataModel transaction = dataSet.get(position);
        //adding values to the list item
        imageView.setImageDrawable(mContext.getResources().getDrawable(transaction.getIcon()));
        textViewName.setText(transaction.getProduct_name());
        textViewCost.setText(transaction.getAmount());
        //finally returning the view
        return view;
    }
}

