package com.kard.mediback;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {
    ImageView ivCamera, ivProfilePic;
    CircleImageView ivAvatar;
    NavigationView navView;
    RadioButton paytmRB, upiRB, impsRB, tezRB;
    LinearLayout paytmLL, upiLL, impsLL, tezLL;
    RadioGroup rgPayment;
    FirebaseUser user;
    DatabaseReference myUserRef, myUserTransRef;
    FirebaseDatabase database;
    String walletTV = "";
    int rupees = 0;
    Button btnSubmit;
    DrawerLayout drawer;
    ProgressDialog pd;
    EditText edtName, edtEmail, edtMobile, edtUpi, edtTez, edtPaytm, edtAccNo, edtConfirmAccNo, edtIfsc, edtImpsName;
    String strName, strEmail, strMobile, strUpi, strTez, strPaytm, strAccNo, strConfirmAccNo, strIfsc, strImpsName;
    TextView rupeevalue;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        database = FirebaseDatabase.getInstance();
        pd=new ProgressDialog(this);
        pd.setCancelable(false);
        pd.setMessage("Updating your Profile");
        user = FirebaseAuth.getInstance().getCurrentUser();
        myUserRef = database.getReference("user").child(user.getPhoneNumber());
        navView = (NavigationView) findViewById(R.id.nav_view);
        btnSubmit = (Button) findViewById(R.id.btn_submit);
        ivCamera = (ImageView) findViewById(R.id.iv_camera);
        ivAvatar = (CircleImageView) findViewById(R.id.iv_avatar);
        ivCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnOnClick(v);
            }
        });
        sp = getSharedPreferences("profile_data", MODE_PRIVATE);
        rgPayment = (RadioGroup) findViewById(R.id.rg_payment);
        paytmRB = (RadioButton) findViewById(R.id.paytmRB);
        upiRB = (RadioButton) findViewById(R.id.upiRB);
        impsRB = (RadioButton) findViewById(R.id.impsRB);
        tezRB = (RadioButton) findViewById(R.id.tezRB);
        paytmLL = (LinearLayout) findViewById(R.id.paytmlinearlayout);
        upiLL = (LinearLayout) findViewById(R.id.upilinearlayout);
        impsLL = (LinearLayout) findViewById(R.id.impslinearlayout);
        tezLL = (LinearLayout) findViewById(R.id.tezlinearlayout);

        edtName = (EditText) findViewById(R.id.edt_name);
        edtEmail = (EditText) findViewById(R.id.edt_email);
        edtMobile = (EditText) findViewById(R.id.edt_mobile);
        edtTez = (EditText) findViewById(R.id.tezidedittext);
        edtPaytm = (EditText) findViewById(R.id.paytmNumberET);
        edtUpi = (EditText) findViewById(R.id.upiidedittext);
        edtAccNo = (EditText) findViewById(R.id.accountNumberET);
        edtConfirmAccNo = (EditText) findViewById(R.id.confirmAccountNumberET);
        edtIfsc = (EditText) findViewById(R.id.ifscNumberET);
        edtImpsName = (EditText) findViewById(R.id.nameET);


        String name = sp.getString("name", null);
        String mobile = sp.getString("mobile", null);
        String email = sp.getString("email", null);
        String paytm = sp.getString("paytm", null);
        String upi = sp.getString("upi", null);
        String tez = sp.getString("tez", null);
        String accno = sp.getString("accno", null);
        String confirmaccno = sp.getString("confirmaccno", null);
        String ifsc = sp.getString("ifsc", null);
        String impsname = sp.getString("impsname", null);
        String imagepath = sp.getString("path", null);

        if (imagepath != null) {
            Log.e("imagepath", imagepath);
            try {
                Bitmap bitmap;
                BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
                bitmap = BitmapFactory.decodeFile(imagepath, bitmapOptions);
                ivAvatar.setImageBitmap(bitmap);
            } catch (Exception e) {
                ivAvatar.setImageResource(R.drawable.avatar2);
            }
        } else {
            ivAvatar.setImageResource(R.drawable.avatar2);
        }
        if (name != null) {
            edtName.setText(name);
        }
        if (mobile != null) {
            edtMobile.setText(mobile);
        }
        if (email != null) {
            edtEmail.setText(email);
        }
        if (paytm != null&&(!(paytm.equals("")))) {
            edtPaytm.setText(paytm);
        }
        if (upi != null && (!(upi.equals("")))) {
            edtUpi.setText(upi);
        }
        if (tez != null&&(!(tez.equals("")))) {
            edtTez.setText(tez);
        }
        if (accno != null&&(!(accno.equals("")))) {
            edtAccNo.setText(accno);
        }
        if (confirmaccno != null&&(!(confirmaccno.equals("")))) {
            edtConfirmAccNo.setText(confirmaccno);
        }
        if (ifsc != null&&(!(ifsc.equals("")))) {
            edtIfsc.setText(ifsc);
        }
        if (impsname != null&&(!(impsname.equals("")))) {
            edtImpsName.setText(impsname);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 0);
        }

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pd.show();
                strName = edtName.getText().toString();
                strEmail = edtEmail.getText().toString();
                strMobile = edtMobile.getText().toString();
                strTez = edtTez.getText().toString();
                strPaytm = edtPaytm.getText().toString();
                strUpi = edtUpi.getText().toString();
                strAccNo = edtAccNo.getText().toString();
                strConfirmAccNo = edtConfirmAccNo.getText().toString();
                strIfsc = edtIfsc.getText().toString();
                strImpsName = edtImpsName.getText().toString();
                SharedPreferences sp = getSharedPreferences("profile_data", MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                if (strName.equals("")) {
                    Toast.makeText(getApplicationContext(), "Enter the Name", Toast.LENGTH_LONG).show();
                } else if (strEmail.equals("")) {
                    Toast.makeText(getApplicationContext(), "Enter the Email", Toast.LENGTH_LONG).show();
                } else if (strMobile.equals("")) {
                    Toast.makeText(getApplicationContext(), "Enter the Mobile Number", Toast.LENGTH_LONG).show();
                } else if (paytmRB.isChecked() && strPaytm.equals("")) {
                    Toast.makeText(getApplicationContext(), "Enter the Paytm Number", Toast.LENGTH_LONG).show();
                }else if (paytmRB.isChecked() && strPaytm.length()<10) {
                    Toast.makeText(getApplicationContext(), "Enter the Valid Paytm Number", Toast.LENGTH_LONG).show();
                } else if (upiRB.isChecked() && strUpi.equals("")) {
                    Toast.makeText(getApplicationContext(), "Enter the UPI Number", Toast.LENGTH_LONG).show();
                }else if (upiRB.isChecked() && strUpi.length()<10) {
                    Toast.makeText(getApplicationContext(), "Enter the Valid UPI Number", Toast.LENGTH_LONG).show();
                } else if (impsRB.isChecked() && (strAccNo.equals("") || strConfirmAccNo.equals("") || strIfsc.equals("") || strImpsName.equals(""))) {
                    Toast.makeText(getApplicationContext(), "Enter the Account Details", Toast.LENGTH_LONG).show();
                }else if (impsRB.isChecked() && (strAccNo.equals(strConfirmAccNo))) {
                    Toast.makeText(getApplicationContext(), "Account Number and Confirm Acc number is not same", Toast.LENGTH_LONG).show();
                } else if (tezRB.isChecked() && strTez.equals("")) {
                    Toast.makeText(getApplicationContext(), "Enter the Tez Number", Toast.LENGTH_LONG).show();
                } else {
                    editor.putString("name", strName);
                    editor.putString("mobile", strMobile);
                    editor.putString("email", strEmail);
                    editor.putString("paytm", strPaytm);
                    editor.putString("upi", strUpi);
                    editor.putString("accno", strAccNo);
                    editor.putString("confirmaccno", strConfirmAccNo);
                    editor.putString("ifsc", strIfsc);
                    editor.putString("impsname", strImpsName);
                    editor.putString("tez", strTez);
                    editor.commit();
                    saveImage();
                    Toast.makeText(getApplicationContext(), "Profile is Updated", Toast.LENGTH_LONG).show();
                }
                pd.dismiss();

            }
        });
        try {
            myUserRef = database.getReference("user").child(user.getPhoneNumber());
            myUserRef.child("walletAmount").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    try {
                        walletTV = dataSnapshot.getValue().toString();
                    } catch (Exception ex) {
                        walletTV = "0";
                    }
                    rupees = Integer.parseInt(walletTV);
                    setupBadge();
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    // Failed to read value
                    Log.e("Hey", "Failed to read app title value.", error.toException());
                }
            });
        } catch (Exception ex) {

        }
        rgPayment.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.upiRB:
                        paytmLL.setVisibility(View.GONE);
                        upiLL.setVisibility(View.VISIBLE);
                        impsLL.setVisibility(View.GONE);
                        tezLL.setVisibility(View.GONE);
                        break;
                    case R.id.paytmRB:
                        paytmLL.setVisibility(View.VISIBLE);
                        upiLL.setVisibility(View.GONE);
                        impsLL.setVisibility(View.GONE);
                        tezLL.setVisibility(View.GONE);
                        break;
                    case R.id.impsRB:
                        paytmLL.setVisibility(View.GONE);
                        upiLL.setVisibility(View.GONE);
                        impsLL.setVisibility(View.VISIBLE);
                        tezLL.setVisibility(View.GONE);
                        break;
                    case R.id.tezRB:
                        paytmLL.setVisibility(View.GONE);
                        upiLL.setVisibility(View.GONE);
                        impsLL.setVisibility(View.GONE);
                        tezLL.setVisibility(View.VISIBLE);
                        break;
                }
            }
        });


        navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {

                switch (item.getItemId()) {
                    case R.id.nav_profile:
                        drawer.closeDrawer(Gravity.START, false);
                        return true;
                    case R.id.nav_home:
                        Intent i1 = new Intent(ProfileActivity.this, HomeActivity.class);
                        startActivity(i1);
                        finish();
                        return true;

                    case R.id.nav_wallet:
                        Intent i = new Intent(ProfileActivity.this, MyWalletTransaction.class);
                        startActivity(i);
                        finish();
                        return true;
                    case R.id.nav_logout:
                        Toast.makeText(getApplicationContext(), "logged out", Toast.LENGTH_LONG).show();

                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void saveImage() {
        BitmapDrawable drawable = (BitmapDrawable) ivAvatar.getDrawable();
        if (drawable != null) {
            Bitmap bitmap = drawable.getBitmap();
            File sdCardDirectory = Environment.getExternalStorageDirectory();
            File image = new File(sdCardDirectory, "test.png");
            boolean success = false;
            // Encode the file as a PNG image.
            FileOutputStream outStream;
            try {

                outStream = new FileOutputStream(image);
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, outStream);
                /* 100 to keep full quality of the image */

                outStream.flush();
                outStream.close();
                success = true;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (success) {
                Toast.makeText(getApplicationContext(), "Image saved with success", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "Error during image saving", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void btnOnClick(View view) {
        PopupMenu popup = new PopupMenu(ProfileActivity.this, ivCamera);
        //Inflating the Popup using xml file
        popup.getMenuInflater()
                .inflate(R.menu.menu_camera, popup.getMenu());

        //registering popup with OnMenuItemClickListener
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.iv_camera:
                        opencamera();
                        break;
                    case R.id.iv_gallery:
                        opengallery();
                        break;
                }
                return true;
            }
        });

        popup.show();
    }

    private void opencamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp.jpg");
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
        startActivityForResult(intent, 1);
    }

    private void opengallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 2);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(ProfileActivity.this, HomeActivity.class);
        startActivity(i);
        finish();
    }

    @Override

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                File f = new File(Environment.getExternalStorageDirectory().toString());
                for (File temp : f.listFiles()) {
                    if (temp.getName().equals("temp.jpg")) {
                        f = temp;
                        break;
                    }
                }
                try {
                    Bitmap bitmap;
                    BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
                    bitmap = BitmapFactory.decodeFile(f.getAbsolutePath(), bitmapOptions);
                    ivAvatar.setImageBitmap(bitmap);
                    SharedPreferences sp = getSharedPreferences("profile_data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putString("path", f.getAbsolutePath());
                    editor.commit();
                    f.delete();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (requestCode == 2) {
                Uri selectedImage = data.getData();
                String[] filePath = {MediaStore.Images.Media.DATA};
                Cursor c = getContentResolver().query(selectedImage, filePath, null, null, null);
                c.moveToFirst();
                int columnIndex = c.getColumnIndex(filePath[0]);
                String picturePath = c.getString(columnIndex);
                c.close();
                Bitmap thumbnail = BitmapFactory.decodeFile(picturePath);
                ivAvatar.setImageBitmap(thumbnail);
                SharedPreferences sp = getSharedPreferences("profile_data", MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("path", picturePath);
                editor.commit();
            }
        }
    }


    public void saveprofile() {
        myUserTransRef = database.getReference("user").child(user.getPhoneNumber());
        myUserTransRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                for (DataSnapshot childDataSnapshot : dataSnapshot.getChildren()) {
                    myUserRef.child("name").push().setValue(1);
                    //Toast.makeText(HomeActivity.this, "name is "+childDataSnapshot.child("product_name").getValue(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.popup, menu);
        final MenuItem menuItem = menu.findItem(R.id.action_drawer_rupee);
        View actionView = MenuItemCompat.getActionView(menuItem);
        rupeevalue = (TextView) actionView.findViewById(R.id.rupee_badge);
        actionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOptionsItemSelected(menuItem);
            }
        });
        setupBadge();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_drawer_search:
                return true;
            case R.id.action_drawer_rupee:
                Intent i1 = new Intent(ProfileActivity.this, MyWalletTransaction.class);
                startActivity(i1);
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void setupBadge() {
        if (rupeevalue != null) {
            if (rupees == 0) {
                if (rupeevalue.getVisibility() != View.GONE) {
                    rupeevalue.setVisibility(View.GONE);
                }
            } else {
                rupeevalue.setText(String.valueOf(rupees));
                if (rupeevalue.getVisibility() != View.VISIBLE) {
                    rupeevalue.setVisibility(View.VISIBLE);
                }
            }
        }
    }
}
