package com.kard.mediback;

import android.app.Activity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyListAdapter extends ArrayAdapter<TransactionDataModel> {

    private final Activity context;
    ArrayList<TransactionDataModel> heroList;
    //the layout resource file for the list items
    int resource;
    public MyListAdapter(Activity context, int resource,ArrayList<TransactionDataModel> heroList) {
        // TODO Auto-generated constructor stub
        super(context, resource, heroList);
        this.context = context;
        this.resource = resource;
        this.heroList = heroList;

    }
    //this will return the ListView Item as a View
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        //we need to get the view of the xml for our list item
        //And for this we need a layoutinflater
        LayoutInflater layoutInflater = LayoutInflater.from(context);

        //getting the view
        View view = layoutInflater.inflate(resource, null, false);

        //getting the view elements of the list from the view
        ImageView imageView = view.findViewById(R.id.add_remove_icon);
        TextView textViewName = view.findViewById(R.id.product_name);
        TextView textViewCost = view.findViewById(R.id.product_cost);

        //getting the hero of the specified position
        TransactionDataModel hero = heroList.get(position);
        //adding values to the list item
        imageView.setImageDrawable(context.getResources().getDrawable(hero.getIcon()));
        textViewName.setText(hero.getProduct_name());
        textViewCost.setText(hero.getAmount());
        //finally returning the view
        return view;
    }
}
