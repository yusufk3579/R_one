package com.kard.mediback;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.support.design.widget.NavigationView;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MyWalletTransaction extends AppCompatActivity {
    RecyclerView rvMyWallet;
    WalletAdapter mAdapter;
    FirebaseUser user;
    FirebaseDatabase database;
//    Button btnWithdraw;
    NavigationView navView;
    DatabaseReference myUserTransRef, myUserRef;
    ArrayList<TransactionDataModel> dataModels;
    Dialog myDialog;
    String walletTV = "";
    int rupees = 0;
    TextView rupeevalue;
    DrawerLayout drawer;
    AlertDialog.Builder alert;
    LayoutInflater inflater;
    View alertLayout;
    Dialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_wallet_transaction);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 0);
        }
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navView = (NavigationView) findViewById(R.id.nav_view);
//        btnWithdraw=(Button) findViewById(R.id.btn_withdraw);
        user = FirebaseAuth.getInstance().getCurrentUser();
        database = FirebaseDatabase.getInstance();
        rvMyWallet = (RecyclerView) findViewById(R.id.rv_mywallet);
        dataModels = new ArrayList<>();
        myWallet();
        myTransactionList();

        rvMyWallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowPopup(v);
            }
        });

        navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_profile:
                        Intent i = new Intent(MyWalletTransaction.this, ProfileActivity.class);
                        startActivity(i);
                        finish();
                        return true;

                    case R.id.nav_home:
                        Intent i1 = new Intent(MyWalletTransaction.this, HomeActivity.class);
                        startActivity(i1);
                        finish();

                    case R.id.nav_wallet:
                        drawer.closeDrawer(Gravity.START, false);
                        return true;
                    case R.id.nav_logout:
                        Toast.makeText(getApplicationContext(), "logged out", Toast.LENGTH_LONG).show();
                        return true;
                    default:
                        return true;
                }
            }
        });




    }

    private void myWallet() {
        myUserRef = database.getReference("user").child(user.getPhoneNumber());
        try {
            myUserRef = database.getReference("user").child(user.getPhoneNumber());
            myUserRef.child("walletAmount").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    try {
                        walletTV = dataSnapshot.getValue().toString();
                    } catch (Exception ex) {
                        walletTV = "0";
                    }
                    rupees = Integer.parseInt(walletTV);
                    setupBadge();
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    // Failed to read value
                    Log.e("Hey", "Failed to read app title value.", error.toException());
                }
            });
        } catch (Exception ex) {

        }
    }

    public void updateTransactionListView(String product_name_lv, String amount_lv, String type) {
        if (type.equalsIgnoreCase("deposit")) {
            dataModels.add(new TransactionDataModel(product_name_lv, amount_lv, R.drawable.add));
            //Toast.makeText(this, "name is "+product_name_lv+" amount is "+amount_lv+" type is "+type, Toast.LENGTH_SHORT).show();
//            rvMyWallet.invalidateViews();
        } else if (type.equalsIgnoreCase("withdraw")) {
            dataModels.add(new TransactionDataModel(product_name_lv, amount_lv, R.drawable.withdraw));
//            list.invalidateViews();
        }
        Log.e("data in models", dataModels.size() + "");
        mAdapter = new WalletAdapter(dataModels, this);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        rvMyWallet.setLayoutManager(mLayoutManager);
        rvMyWallet.setAdapter(mAdapter);

    }


    private void myTransactionList() {
        try {
            Log.e("Phone ", user.getPhoneNumber());
            myUserTransRef = database.getReference("user").child(user.getPhoneNumber());
            myUserTransRef.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                    for (DataSnapshot childDataSnapshot : dataSnapshot.getChildren()) {
                        //Log.v(TAG,""+ childDataSnapshot.getKey()); //displays the key for the node
                        if (childDataSnapshot.child("product_name").getValue().toString().equalsIgnoreCase("withdraw")) {
                            updateTransactionListView(childDataSnapshot.child("product_name").getValue().toString(), "Rs " + childDataSnapshot.child("amount").getValue().toString() + "/- on " + childDataSnapshot.child("used_date_time").getValue().toString(), "withdraw");
                        } else {
                            updateTransactionListView(childDataSnapshot.child("product_name").getValue().toString(), "Rs " + childDataSnapshot.child("amount").getValue().toString() + "/- on " + childDataSnapshot.child("used_date_time").getValue().toString(), "deposit");

                        }
                        //Toast.makeText(HomeActivity.this, "name is "+childDataSnapshot.child("product_name").getValue(), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                    // here in dataSnapshot you will the detail for which the value is changed,using this you can update the list.
                }

                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {
                }

                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String s) {
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            });
        } catch (Exception ex) {

        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(MyWalletTransaction.this, HomeActivity.class);
        startActivity(i);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.popup, menu);
        final MenuItem menuItem = menu.findItem(R.id.action_drawer_rupee);
        View actionView = MenuItemCompat.getActionView(menuItem);
        rupeevalue = (TextView) actionView.findViewById(R.id.rupee_badge);
        actionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOptionsItemSelected(menuItem);
            }
        });
        setupBadge();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_drawer_search:
                return true;
            case R.id.action_drawer_rupee:
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void setupBadge() {
        if (rupeevalue != null) {
            if (rupees == 0) {
                if (rupeevalue.getVisibility() != View.GONE) {
                    rupeevalue.setVisibility(View.GONE);
                }
            } else {
                rupeevalue.setText(String.valueOf(rupees));
                if (rupeevalue.getVisibility() != View.VISIBLE) {
                    rupeevalue.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    public void ShowPopup(View v) {
        myDialog = new Dialog(this);
        TextView txtclose;
        Button btnClose;
        myDialog.setContentView(R.layout.popup_singletransaction);
        txtclose = (TextView) myDialog.findViewById(R.id.txtclose);
        btnClose = (Button) myDialog.findViewById(R.id.btnfollow);
        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }

}
