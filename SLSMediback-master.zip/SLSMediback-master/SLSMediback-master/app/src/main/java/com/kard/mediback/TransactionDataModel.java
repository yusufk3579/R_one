package com.kard.mediback;

public class TransactionDataModel {

    String product_name;
    String amount;
    Integer icon;

    public TransactionDataModel(String product_name, String amount,Integer icon ) {
        this.product_name=product_name;
        this.amount = amount;
        this.icon = icon;

    }

    public String getProduct_name() {
        return product_name;
    }

    public String getAmount() {
        return amount;
    }

    public Integer getIcon() {
        return icon;
    }
}

