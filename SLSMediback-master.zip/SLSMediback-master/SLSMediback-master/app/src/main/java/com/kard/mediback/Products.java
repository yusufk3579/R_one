package com.kard.mediback;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Products {
    private String qr_value;
    private String product_name;
    private String amount;
    private boolean used;
    private String used_by;
    private String used_date;
    private String used_time;
    public Products(){

    }
    public Products(String qr_value, String product_name, String amount) {
        this.qr_value = qr_value;
        this.product_name = product_name;
        this.amount = amount;
    }
    public Products(String qr_value, String product_name, String amount,Boolean used,String used_by,String used_date,String used_time) {
        this.qr_value = qr_value;
        this.product_name = product_name;
        this.amount = amount;
        this.used = used;
        this.used_by = used_by;
        this.used_date = used_date;
        this.used_time = used_time;
    }

    public String getQr_value() {
        return qr_value;
    }

    public String getProduct_name() {
        return product_name;
    }

    public String getAmount() {
        return amount;
    }

    public boolean isUsed() {
        return used;
    }

    public String getUsed_by() {
        return used_by;
    }

    public String getUsed_date() {
        return used_date;
    }

    public String getUsed_time() {
        return used_time;
    }
}
