package com.kard.mediback;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class WalletAdapter extends RecyclerView.Adapter<WalletAdapter.MyViewHolder> {
    private ArrayList<TransactionDataModel> transactionlist;
    Context mContext;

    public WalletAdapter(ArrayList<TransactionDataModel> transactionlist, Context con) {
        this.transactionlist = transactionlist;
        this.mContext=con;
    }

    @Override
    public MyViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.transaction_listview, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder( WalletAdapter.MyViewHolder holder, int position) {
        holder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mContext,"clicked", Toast.LENGTH_LONG).show();
            }
        });
        TransactionDataModel transaction = transactionlist.get(position);

        holder.imageView.setImageDrawable(mContext.getResources().getDrawable(transaction.getIcon()));
        holder.textViewName.setText(transaction.getProduct_name());
        holder.icon.setText(transaction.getAmount());

    }

    @Override
    public int getItemCount() {
        return transactionlist.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textViewName;
        TextView icon;

        public MyViewHolder(View view) {
            super(view);
             imageView = view.findViewById(R.id.add_remove_icon);
             textViewName = view.findViewById(R.id.product_name);
             icon = view.findViewById(R.id.product_cost);
        }
    }
}
