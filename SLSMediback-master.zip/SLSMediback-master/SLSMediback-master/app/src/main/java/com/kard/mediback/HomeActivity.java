package com.kard.mediback;

import android.Manifest;
import android.app.Activity;
import android.content.SharedPreferences;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.design.widget.NavigationView;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class HomeActivity extends AppCompatActivity {
    ListView list;
    Dialog dialog,dialog1;
    ArrayList<TransactionDataModel> dataModels;
    SharedPreferences sharedpreferences;
    private static TransactionCustomAdapter adapter;
    public static final String MyPREFERENCES = "SLS_PREFS";
    public static final String UsedKey = "usedKey";
    //qr code scanner object
    private IntentIntegrator qrScan;
    TextView rupeevalue;
    int rupees = 0;
    AlertDialog alertdialog;
    AlertDialog.Builder alert;
    LayoutInflater inflater;
    View alertLayout;
    EditText oKeditText;
    FirebaseDatabase database;
    DatabaseReference myProductRef;
    NavigationView navView;
    DatabaseReference myUserRef, myUserTransRef;
    ProgressBar mProgressBar;
    FirebaseUser user;
    TextView walletTextView, withdrawTV;
    Button withdrawal_button;
    String walletTV = "";
    String sls_value = "";
    SharedPreferences sp,sls_settings;
    DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 0);
        }
        navView = (NavigationView) findViewById(R.id.nav_view);
        user = FirebaseAuth.getInstance().getCurrentUser();
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String name = preferences.getString("Name", "");
        if (!name.equalsIgnoreCase("")) {
            //Toast.makeText(this, "Inside IF "+name, Toast.LENGTH_SHORT).show();
        } else {
            //Toast.makeText(this, "inside else", Toast.LENGTH_SHORT).show();
        }
        TextView welcome_text = (TextView) findViewById(R.id.welcome_tv);
        welcome_text.setText("Welcome " + user.getPhoneNumber());
        list = (ListView) findViewById(R.id.homepage_transaction_listview);
        dataModels = new ArrayList<>();
        MyListAdapter adapter = new MyListAdapter(this, R.layout.transaction_listview, dataModels);
        list.setAdapter(adapter);
        list.setAdapter(adapter);
        oKeditText = (EditText) findViewById(R.id.scan_value_edit_text);
        //intializing scan object
        qrScan = new IntentIntegrator(this);
        database = FirebaseDatabase.getInstance();
        myProductRef = database.getReference("products");
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        //Logic for loading list view initially from db
        //addPrevioustransactionsToLV();
        walletTextView = (TextView) findViewById(R.id.walletAmountDisplay);
        withdrawTV = (TextView) findViewById(R.id.withdrawTV);
        withdrawal_button = (Button) findViewById(R.id.withdraw_button);
        try {
            myUserRef = database.getReference("user").child(user.getPhoneNumber());
            myUserRef.child("walletAmount").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    try {
                        walletTV = dataSnapshot.getValue().toString();
                    } catch (Exception ex) {
                        walletTV = "0";
                    }
                    if (Integer.parseInt(walletTV) >= 100) {
                        withdrawal_button.setVisibility(View.VISIBLE);
                        withdrawTV.setVisibility(View.GONE);
                    } else {
                        withdrawal_button.setVisibility(View.GONE);
                        withdrawTV.setVisibility(View.VISIBLE);
                    }
                    walletTextView.setText("Rs " + walletTV + " /-");
                    rupees = Integer.parseInt(walletTV);
                    setupBadge();
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    // Failed to read value
                    Log.e("Hey", "Failed to read app title value.", error.toException());
                }
            });
        } catch (Exception ex) {

        }
        try {
            myUserTransRef = database.getReference("user").child(user.getPhoneNumber());
            myUserTransRef.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                    for (DataSnapshot childDataSnapshot : dataSnapshot.getChildren()) {
                        //Log.v(TAG,""+ childDataSnapshot.getKey()); //displays the key for the node
                        if (childDataSnapshot.child("product_name").getValue().toString().equalsIgnoreCase("withdraw")) {
                            updateTransactionListView(childDataSnapshot.child("product_name").getValue().toString(), "Rs " + childDataSnapshot.child("amount").getValue().toString() + "/- on " + childDataSnapshot.child("used_date_time").getValue().toString(), "withdraw");
                        } else {
                            updateTransactionListView(childDataSnapshot.child("product_name").getValue().toString(), "Rs " + childDataSnapshot.child("amount").getValue().toString() + "/- on " + childDataSnapshot.child("used_date_time").getValue().toString(), "deposit");
                        }
                        //Toast.makeText(HomeActivity.this, "name is "+childDataSnapshot.child("product_name").getValue(), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                    // here in dataSnapshot you will the detail for which the value is changed,using this you can update the list.
                }

                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {
                }

                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String s) {
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            });
        } catch (Exception ex) {

        }

        list.setOnTouchListener(new View.OnTouchListener() {
            // Setting on Touch Listener for handling the touch inside ScrollView
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Disallow the touch request for parent scroll on touch of child view
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                LayoutInflater inflater = getLayoutInflater();
                View alertLayout = inflater.inflate(R.layout.popup_transaction_details, null);
                AlertDialog.Builder alert = new AlertDialog.Builder(HomeActivity.this);
                alert.setView(alertLayout);
                alert.setCancelable(true);
                final ImageView ivClose = (ImageView) alertLayout.findViewById(R.id.iv_close);
                ivClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog1.dismiss();
                    }
                });

                dialog1 = alert.create();
                dialog1.show();
            }
        });

        withdrawal_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inflater = getLayoutInflater();
                alertLayout = inflater.inflate(R.layout.withdraw_options, null);
                alert = new AlertDialog.Builder(HomeActivity.this);
                alert.setView(alertLayout);
                alert.setCancelable(true);
                EditText withdrawAmountET = (EditText) alertLayout.findViewById(R.id.withdraw_amount_req);
                withdrawAmountET.setText(walletTV);
                withdrawAmountET.setEnabled(false);
                RadioGroup radioGroup = (RadioGroup) alertLayout.findViewById(R.id.radioGroup);
                final LinearLayout paytmLL = (LinearLayout) alertLayout.findViewById(R.id.paytmlinearlayout);
                final LinearLayout upiLL = (LinearLayout) alertLayout.findViewById(R.id.upilinearlayout);
                final LinearLayout impsLL = (LinearLayout) alertLayout.findViewById(R.id.impslinearlayout);
                final LinearLayout tezLL = (LinearLayout) alertLayout.findViewById(R.id.tezlinearlayout);
                final ImageView ivClose = (ImageView) alertLayout.findViewById(R.id.iv_close);
                final EditText paytmNumberET = (EditText) alertLayout.findViewById(R.id.paytmNumberET);
                final EditText upiET = (EditText) alertLayout.findViewById(R.id.upiidedittext);
                final EditText tezNumberET = (EditText) alertLayout.findViewById(R.id.tezidedittext);
                final EditText accountNumberET = (EditText) alertLayout.findViewById(R.id.accountNumberET);
                final EditText confirmNumberET = (EditText) alertLayout.findViewById(R.id.confirmAccountNumberET);
                final EditText ifscNumberET = (EditText) alertLayout.findViewById(R.id.ifscNumberET);
                final EditText nameET = (EditText) alertLayout.findViewById(R.id.nameET);
                sp = getSharedPreferences("profile_data", MODE_PRIVATE);
                String name1 = sp.getString("name", null);
                String mobile = sp.getString("mobile", null);
                String email = sp.getString("email", null);
                String paytm = sp.getString("paytm", null);
                String upi = sp.getString("upi", null);
                String tez = sp.getString("tez", null);
                String accno = sp.getString("accno", null);
                String confirmaccno = sp.getString("confirmaccno", null);
                String ifsc = sp.getString("ifsc", null);
                String impsname = sp.getString("impsname", null);
                String imagepath = sp.getString("path", null);
                if (paytm != null&&(!(paytm.equals("")))) {
                    paytmNumberET.setText(paytm);
                }
                if (upi != null && (!(upi.equals("")))) {
                    upiET.setText(upi);
                }
                if (tez != null&&(!(tez.equals("")))) {
                    tezNumberET.setText(tez);
                }
                if (accno != null&&(!(accno.equals("")))) {
                    accountNumberET.setText(accno);
                }
                if (confirmaccno != null&&(!(confirmaccno.equals("")))) {
                    confirmNumberET.setText(confirmaccno);
                }
                if (ifsc != null&&(!(ifsc.equals("")))) {
                    ifscNumberET.setText(ifsc);
                }
                if (impsname != null&&(!(impsname.equals("")))) {
                    nameET.setText(impsname);
                }

                final Button btnPaytmwithdrawalbutton = (Button) alertLayout.findViewById(R.id.paytmwithdrawalbutton);
                final Button btnUpiwithdrawalbutton = (Button) alertLayout.findViewById(R.id.upiwithdrawalbutton);
                final Button btnImpswithdrawalbutton = (Button) alertLayout.findViewById(R.id.impswithdrawalbutton);
                final Button btnTezwithdrawalbutton = (Button) alertLayout.findViewById(R.id.tezwithdrawalbutton);
                btnPaytmwithdrawalbutton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final String paytmNumber = paytmNumberET.getText().toString();
                        if (paytmNumber.length() == 10) {
                            final String walletRefID = new SimpleDateFormat("ddMMyyyy").format(new Date()) + user.getPhoneNumber().substring(3) + getAlphaNumericString(3);
                            final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                            DatabaseReference transaction_ref = ref.child("user").child(user.getPhoneNumber());
                            DatabaseReference withdrawamount_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("amount");
                            withdrawamount_ser_ref.setValue(walletTV);
                            DatabaseReference product_name_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("product_name");
                            product_name_ser_ref.setValue("withdraw");
                            String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
                            DatabaseReference date_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("used_date_time");
                            date_ser_ref.setValue(mydate);
                            DatabaseReference withdraw_amount_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_amount");
                            withdraw_amount_ser_ref.setValue(walletTV);
                            DatabaseReference withdraw_type_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_type");
                            withdraw_type_ser_ref.setValue("paytm - " + paytmNumber);
                            DatabaseReference withdraw_time_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_time");
                            withdraw_time_ser_ref.setValue(mydate);
                            DatabaseReference withdraw_by_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_by");
                            withdraw_by_ser_ref.setValue(user.getPhoneNumber());
                            DatabaseReference withdraw_status_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_refunded");
                            withdraw_status_ser_ref.setValue(false);
                            DatabaseReference walletAmount = ref.child("user").child(user.getPhoneNumber()).child("walletAmount");
                            int updated_wallet_amount = 0;
                            String final_wallet = String.valueOf(updated_wallet_amount);
                            walletAmount.setValue(final_wallet);
                            Intent intent = getIntent();
                            finish();
                            startActivity(intent);
                        } else {
                            Toast.makeText(HomeActivity.this, "Enter Valid Mobile number", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                btnUpiwithdrawalbutton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final String upi = upiET.getText().toString();
                        if(!(upi.equals(""))) {
                            final String walletRefID = new SimpleDateFormat("ddMMyyyy").format(new Date()) + user.getPhoneNumber().substring(3) + getAlphaNumericString(3);
                            final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                            DatabaseReference transaction_ref = ref.child("user").child(user.getPhoneNumber());
                            DatabaseReference withdrawamount_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("amount");
                            withdrawamount_ser_ref.setValue(walletTV);
                            DatabaseReference product_name_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("product_name");
                            product_name_ser_ref.setValue("withdraw");
                            String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
                            DatabaseReference date_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("used_date_time");
                            date_ser_ref.setValue(mydate);
                            DatabaseReference withdraw_amount_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_amount");
                            withdraw_amount_ser_ref.setValue(walletTV);
                            DatabaseReference withdraw_type_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_type");
                            withdraw_type_ser_ref.setValue("UPI - " + upi);
                            DatabaseReference withdraw_time_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_time");
                            withdraw_time_ser_ref.setValue(mydate);
                            DatabaseReference withdraw_by_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_by");
                            withdraw_by_ser_ref.setValue(user.getPhoneNumber());
                            DatabaseReference withdraw_status_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_refunded");
                            withdraw_status_ser_ref.setValue(false);
                            DatabaseReference walletAmount = ref.child("user").child(user.getPhoneNumber()).child("walletAmount");
                            int updated_wallet_amount = 0;
                            String final_wallet = String.valueOf(updated_wallet_amount);
                            walletAmount.setValue(final_wallet);
                            dialog.dismiss();
                        }
                        else {
                            Toast.makeText(HomeActivity.this, "Enter Valid UPI number", Toast.LENGTH_SHORT).show();

                        }
                    }
                });
                btnImpswithdrawalbutton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final String accountNumber = accountNumberET.getText().toString();
                        final String confirmNumber = confirmNumberET.getText().toString();
                        if (!(accountNumber.equals("")) || !(confirmNumber.equals(""))) {
                            if (confirmNumber.equalsIgnoreCase(accountNumber)) {
                                final String walletRefID = new SimpleDateFormat("ddMMyyyy").format(new Date()) + user.getPhoneNumber().substring(3) + getAlphaNumericString(3);
                                final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                                DatabaseReference transaction_ref = ref.child("user").child(user.getPhoneNumber());
                                DatabaseReference withdrawamount_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("amount");
                                withdrawamount_ser_ref.setValue(walletTV);
                                DatabaseReference product_name_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("product_name");
                                product_name_ser_ref.setValue("withdraw");
                                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
                                DatabaseReference date_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("used_date_time");
                                date_ser_ref.setValue(mydate);
                                DatabaseReference withdraw_amount_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_amount");
                                withdraw_amount_ser_ref.setValue(walletTV);
                                DatabaseReference withdraw_type_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_type");
                                withdraw_type_ser_ref.setValue("IMPS - Account Number : " + accountNumber + " , IFSC : " + ifscNumberET.getText().toString() + " , Name : " + nameET.getText().toString());
                                DatabaseReference withdraw_time_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_time");
                                withdraw_time_ser_ref.setValue(mydate);
                                DatabaseReference withdraw_by_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_by");
                                withdraw_by_ser_ref.setValue(user.getPhoneNumber());
                                DatabaseReference withdraw_status_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_refunded");
                                withdraw_status_ser_ref.setValue(false);
                                DatabaseReference walletAmount = ref.child("user").child(user.getPhoneNumber()).child("walletAmount");
                                int updated_wallet_amount = 0;
                                String final_wallet = String.valueOf(updated_wallet_amount);
                                walletAmount.setValue(final_wallet);
                                dialog.dismiss();
                            } else {
                                Toast.makeText(HomeActivity.this, "Enter Valid details & Check Account number", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(HomeActivity.this, "Enter Valid details & Check Account number", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                btnTezwithdrawalbutton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final String tezNumber = tezNumberET.getText().toString();
                        if (tezNumber.length() == 10) {
                            final String walletRefID = new SimpleDateFormat("ddMMyyyy").format(new Date()) + user.getPhoneNumber().substring(3) + getAlphaNumericString(3);
                            final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                            DatabaseReference transaction_ref = ref.child("user").child(user.getPhoneNumber());
                            DatabaseReference withdrawamount_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("amount");
                            withdrawamount_ser_ref.setValue(walletTV);
                            DatabaseReference product_name_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("product_name");
                            product_name_ser_ref.setValue("withdraw");
                            String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
                            DatabaseReference date_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("used_date_time");
                            date_ser_ref.setValue(mydate);
                            DatabaseReference withdraw_amount_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_amount");
                            withdraw_amount_ser_ref.setValue(walletTV);
                            DatabaseReference withdraw_type_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_type");
                            withdraw_type_ser_ref.setValue("Tez Number - " + tezNumber);
                            DatabaseReference withdraw_time_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_time");
                            withdraw_time_ser_ref.setValue(mydate);
                            DatabaseReference withdraw_by_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_by");
                            withdraw_by_ser_ref.setValue(user.getPhoneNumber());
                            DatabaseReference withdraw_status_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_refunded");
                            withdraw_status_ser_ref.setValue(false);
                            DatabaseReference walletAmount = ref.child("user").child(user.getPhoneNumber()).child("walletAmount");
                            int updated_wallet_amount = 0;
                            String final_wallet = String.valueOf(updated_wallet_amount);
                            walletAmount.setValue(final_wallet);
                            dialog.dismiss();
                        } else {
                            Toast.makeText(HomeActivity.this, "Enter Valid Tez number", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                ivClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group, int checkedId) {
                        switch (checkedId) {
                            case R.id.paytmRB:
                                paytmLL.setVisibility(View.VISIBLE);
                                upiLL.setVisibility(View.GONE);
                                impsLL.setVisibility(View.GONE);
                                tezLL.setVisibility(View.GONE);
                                break;
                            case R.id.upiRB:
                                paytmLL.setVisibility(View.GONE);
                                upiLL.setVisibility(View.VISIBLE);
                                impsLL.setVisibility(View.GONE);
                                tezLL.setVisibility(View.GONE);
                                break;
                            case R.id.impsRB:
                                paytmLL.setVisibility(View.GONE);
                                upiLL.setVisibility(View.GONE);
                                impsLL.setVisibility(View.VISIBLE);
                                tezLL.setVisibility(View.GONE);
                                break;
                            case R.id.tezRB:
                                paytmLL.setVisibility(View.GONE);
                                upiLL.setVisibility(View.GONE);
                                impsLL.setVisibility(View.GONE);
                                tezLL.setVisibility(View.VISIBLE);
                                break;
                        }
                    }
                });
                dialog = alert.create();
                dialog.show();
            }
        });
        if (!name.equalsIgnoreCase("used")) {
            dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
            dialog.setContentView(R.layout.frame_help);
            dialog.show();
        } else {
            //Toast.makeText(this, "value is "+name, Toast.LENGTH_SHORT).show();
        }

        navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_profile:
                        Intent i = new Intent(HomeActivity.this, ProfileActivity.class);
                        startActivity(i);
                        finish();
                        return true;
                    case R.id.nav_home:
                        drawer.closeDrawer(Gravity.START, false);
                        return true;
                    case R.id.nav_wallet:
                        Intent i1 = new Intent(HomeActivity.this, MyWalletTransaction.class);
                        startActivity(i1);
                        finish();
                        return true;
                    case R.id.nav_logout:
                        Toast.makeText(getApplicationContext(), "logged out", Toast.LENGTH_LONG).show();

                        return true;
                    default:
                        return true;
                }
            }
        });

    }

    public void qrscan(View view) {
        //initiating the qr code scan
        qrScan.initiateScan();
    }

    public void okBtn(View view) {
        String value = oKeditText.getText().toString();
        if (value.length() > 0) {
            playwithscanvalue(value);
        } else {
            Toast.makeText(this, "No value entered", Toast.LENGTH_SHORT).show();
        }
        //hiding keyboard
        ((InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE))
                .toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, 0);
        //clearing textview
        oKeditText.getText().clear();
    }

    //Getting the scan results
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            //if qrcode has nothing in it
            if (result.getContents() == null) {
                Toast.makeText(this, "Result Not Found", Toast.LENGTH_LONG).show();
            } else {
                try {
                    JSONObject obj = new JSONObject(result.getContents());
                    //setting values to textviews
                    playwithscanvalue(obj.toString());
                    //textViewName.setText(obj.getString("name"));
                    //textViewAddress.setText(obj.getString("address"));
                } catch (JSONException e) {
                    e.printStackTrace();
                    playwithscanvalue(result.getContents());
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void playwithscanvalue(final String value) {
        final String[] amount_db = {""};
        final String[] product_name_db = {""};
        final Boolean[] used_db = {false};
        final Boolean[] existInDB = {false};
        final String[] wallet_db = {""};
        //mProgressBar.setVisibility(View.VISIBLE);
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
        //WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
        final DatabaseReference qr_value_db_ref = ref.child("products").child(value).child("amount");
        DatabaseReference rootRef = ref.child("products");
        rootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.hasChild(value)) {
                    // run some code
                    qr_value_db_ref.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            amount_db[0] = dataSnapshot.getValue(String.class);
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                    //Logic for getting product_name
                    DatabaseReference product_name_db_ref = ref.child("products").child(value).child("product_name");
                    product_name_db_ref.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            product_name_db[0] = dataSnapshot.getValue(String.class);
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                    //Logic for getting user wallet amount
                    DatabaseReference wallet_ref = ref.child("user").child(user.getPhoneNumber()).child("walletAmount");
                    wallet_ref.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            wallet_db[0] = dataSnapshot.getValue(String.class);
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            Toast.makeText(HomeActivity.this, "db error wallet " + databaseError, Toast.LENGTH_SHORT).show();
                        }
                    });
                    //Logic for getting used
                    DatabaseReference used_db_ref = ref.child("products").child(value).child("used");
                    used_db_ref.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {

                            used_db[0] = dataSnapshot.getValue(Boolean.class);
                            if (!used_db[0]) {
                                updateAsScannedDB(value);
                                updateTransactionListView(product_name_db[0], amount_db[0], "deposit");
                                updateUsersTransactionHistory(value, amount_db[0], product_name_db[0], wallet_db[0]);
                            } else {
                                ShowInformation("This Coupon is already used, please contact support if you have any issues!!");
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });

                } else {
                    ShowInformation("Scanned Item is not in our Database, Please contact support for more Info");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(HomeActivity.this, "In cancelled", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void ShowInformation(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    public void updateAsScannedDB(String qr_value) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
        DatabaseReference used_db_ref = ref.child("products").child(qr_value).child("used");
        used_db_ref.setValue(true);
        String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
        DatabaseReference date_db_ref = ref.child("products").child(qr_value).child("used_date_time");
        date_db_ref.setValue(mydate);
        DatabaseReference used_by_db_ref = ref.child("products").child(qr_value).child("used_by");
        used_by_db_ref.setValue(user.getPhoneNumber());
    }

    public void updateTransactionListView(String product_name_lv, String amount_lv, String type) {
        if (type.equalsIgnoreCase("deposit")) {
            dataModels.add(new TransactionDataModel(product_name_lv, amount_lv, R.drawable.add));
            //Toast.makeText(this, "name is "+product_name_lv+" amount is "+amount_lv+" type is "+type, Toast.LENGTH_SHORT).show();
            list.invalidateViews();
        } else if (type.equalsIgnoreCase("withdraw")) {
            dataModels.add(new TransactionDataModel(product_name_lv, amount_lv, R.drawable.withdraw));
            list.invalidateViews();
        }

    }

    public void updateUsersTransactionHistory(final String qr_value, final String amount, final String productname, final String dbWalletAmount) {
        //Toast.makeText(this, "Function called", Toast.LENGTH_SHORT).show();
        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
        DatabaseReference transaction_ref = ref.child("user").child(user.getPhoneNumber());
        transaction_ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.hasChild("transactions")) {
                    DatabaseReference amount_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(qr_value).child("amount");
                    amount_ser_ref.setValue(amount);
                    DatabaseReference product_name_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(qr_value).child("product_name");
                    product_name_ser_ref.setValue(productname);
                    String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
                    DatabaseReference date_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(qr_value).child("used_date_time");
                    date_ser_ref.setValue(mydate);
                } else {
                    DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                    DatabaseReference user_ref = ref.child("user").child(user.getPhoneNumber());
                    user_ref.setValue("transactions");
                    ref.child("user").child(user.getPhoneNumber()).child("transactions").setValue(qr_value);
                    DatabaseReference amount_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(qr_value).child("amount");
                    amount_ser_ref.setValue(amount);
                    DatabaseReference product_name_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(qr_value).child("product_name");
                    product_name_ser_ref.setValue(productname);
                    String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
                    DatabaseReference used_date_time_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(qr_value).child("used_date_time");
                    used_date_time_ser_ref.setValue(mydate);
                    //ref.child("user").child(user.getPhoneNumber()).setValue("wallet");

                }
                if (snapshot.hasChild("walletAmount")) {
                    DatabaseReference walletAmount = ref.child("user").child(user.getPhoneNumber()).child("walletAmount");
                    int updated_wallet_amount = Integer.parseInt(dbWalletAmount) + Integer.parseInt(amount);
                    String final_wallet = String.valueOf(updated_wallet_amount);
                    walletAmount.setValue(final_wallet);
                    //Toast.makeText(HomeActivity.this, "dbwallet is "+dbWalletAmount+" amount is "+amount, Toast.LENGTH_SHORT).show();
                } else {
                    DatabaseReference walletAmount = ref.child("user").child(user.getPhoneNumber()).child("walletAmount");
                    String final_wallet = String.valueOf(amount);
                    walletAmount.setValue(final_wallet);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(HomeActivity.this, "In cancel", Toast.LENGTH_SHORT).show();

            }
        });
        //ref.push().setValue("user");
    }

//    public void paytmWithdrawal(View view) {
//        EditText paytmNumberET = (EditText) view.findViewById(R.id.paytmNumberET);
//        final String paytmNumber = paytmNumberET.getText().toString();
//        if (paytmNumber.length() == 10) {
//            final String walletRefID = new SimpleDateFormat("ddMMyyyy").format(new Date()) + user.getPhoneNumber().substring(3) + getAlphaNumericString(3);
//            final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
//            DatabaseReference transaction_ref = ref.child("user").child(user.getPhoneNumber());
//            DatabaseReference withdrawamount_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("amount");
//            withdrawamount_ser_ref.setValue(walletTV);
//            DatabaseReference product_name_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("product_name");
//            product_name_ser_ref.setValue("withdraw");
//            String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
//            DatabaseReference date_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("used_date_time");
//            date_ser_ref.setValue(mydate);
//            DatabaseReference withdraw_amount_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_amount");
//            withdraw_amount_ser_ref.setValue(walletTV);
//            DatabaseReference withdraw_type_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_type");
//            withdraw_type_ser_ref.setValue("paytm - " + paytmNumber);
//            DatabaseReference withdraw_time_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_time");
//            withdraw_time_ser_ref.setValue(mydate);
//            DatabaseReference withdraw_by_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_by");
//            withdraw_by_ser_ref.setValue(user.getPhoneNumber());
//            DatabaseReference withdraw_status_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_refunded");
//            withdraw_status_ser_ref.setValue(false);
//            DatabaseReference walletAmount = ref.child("user").child(user.getPhoneNumber()).child("walletAmount");
//            int updated_wallet_amount = 0;
//            String final_wallet = String.valueOf(updated_wallet_amount);
//            walletAmount.setValue(final_wallet);
//            Intent intent = getIntent();
//            finish();
//            startActivity(intent);
//        } else {
//            Toast.makeText(this, "Enter Valid Mobile number", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    public void upiWithdrawal(View view) {
//        EditText upiET = (EditText) findViewById(R.id.upiidedittext);
//        final String upi = upiET.getText().toString();
//
//        final String walletRefID = new SimpleDateFormat("ddMMyyyy").format(new Date()) + user.getPhoneNumber().substring(3) + getAlphaNumericString(3);
//        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
//        DatabaseReference transaction_ref = ref.child("user").child(user.getPhoneNumber());
//        DatabaseReference withdrawamount_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("amount");
//        withdrawamount_ser_ref.setValue(walletTV);
//        DatabaseReference product_name_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("product_name");
//        product_name_ser_ref.setValue("withdraw");
//        String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
//        DatabaseReference date_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("used_date_time");
//        date_ser_ref.setValue(mydate);
//        DatabaseReference withdraw_amount_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_amount");
//        withdraw_amount_ser_ref.setValue(walletTV);
//        DatabaseReference withdraw_type_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_type");
//        withdraw_type_ser_ref.setValue("UPI - " + upi);
//        DatabaseReference withdraw_time_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_time");
//        withdraw_time_ser_ref.setValue(mydate);
//        DatabaseReference withdraw_by_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_by");
//        withdraw_by_ser_ref.setValue(user.getPhoneNumber());
//        DatabaseReference withdraw_status_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_refunded");
//        withdraw_status_ser_ref.setValue(false);
//        DatabaseReference walletAmount = ref.child("user").child(user.getPhoneNumber()).child("walletAmount");
//        int updated_wallet_amount = 0;
//        String final_wallet = String.valueOf(updated_wallet_amount);
//        walletAmount.setValue(final_wallet);
//        Intent intent = getIntent();
//        finish();
//        startActivity(intent);
//
//    }
//
//    public void impsWithdrawal(View view) {
//        EditText accountNumberET = (EditText) findViewById(R.id.accountNumberET);
//        EditText confirmNumberET = (EditText) findViewById(R.id.confirmAccountNumberET);
//        EditText ifscNumberET = (EditText) findViewById(R.id.ifscNumberET);
//        EditText nameET = (EditText) findViewById(R.id.nameET);
//        final String accountNumber = accountNumberET.getText().toString();
//        final String confirmNumber = confirmNumberET.getText().toString();
//        if (confirmNumber.equalsIgnoreCase(accountNumber)) {
//            final String walletRefID = new SimpleDateFormat("ddMMyyyy").format(new Date()) + user.getPhoneNumber().substring(3) + getAlphaNumericString(3);
//            final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
//            DatabaseReference transaction_ref = ref.child("user").child(user.getPhoneNumber());
//            DatabaseReference withdrawamount_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("amount");
//            withdrawamount_ser_ref.setValue(walletTV);
//            DatabaseReference product_name_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("product_name");
//            product_name_ser_ref.setValue("withdraw");
//            String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
//            DatabaseReference date_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("used_date_time");
//            date_ser_ref.setValue(mydate);
//            DatabaseReference withdraw_amount_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_amount");
//            withdraw_amount_ser_ref.setValue(walletTV);
//            DatabaseReference withdraw_type_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_type");
//            withdraw_type_ser_ref.setValue("IMPS - Account Number : " + accountNumber + " , IFSC : " + ifscNumberET.getText().toString() + " , Name : " + nameET.getText().toString());
//            DatabaseReference withdraw_time_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_time");
//            withdraw_time_ser_ref.setValue(mydate);
//            DatabaseReference withdraw_by_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_by");
//            withdraw_by_ser_ref.setValue(user.getPhoneNumber());
//            DatabaseReference withdraw_status_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_refunded");
//            withdraw_status_ser_ref.setValue(false);
//            DatabaseReference walletAmount = ref.child("user").child(user.getPhoneNumber()).child("walletAmount");
//            int updated_wallet_amount = 0;
//            String final_wallet = String.valueOf(updated_wallet_amount);
//            walletAmount.setValue(final_wallet);
//            Intent intent = getIntent();
//            finish();
//            startActivity(intent);
//
//
//        } else {
//            Toast.makeText(this, "Enter Valid details & Check Account number", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    public void tezWithdrawal(View view) {
//
//        final String tezNumber = tezNumberET.getText().toString();
//        if (tezNumber.length() == 10) {
//            final String walletRefID = new SimpleDateFormat("ddMMyyyy").format(new Date()) + user.getPhoneNumber().substring(3) + getAlphaNumericString(3);
//            final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
//            DatabaseReference transaction_ref = ref.child("user").child(user.getPhoneNumber());
//            DatabaseReference withdrawamount_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("amount");
//            withdrawamount_ser_ref.setValue(walletTV);
//            DatabaseReference product_name_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("product_name");
//            product_name_ser_ref.setValue("withdraw");
//            String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
//            DatabaseReference date_ser_ref = ref.child("user").child(user.getPhoneNumber()).child("transactions").child(walletRefID).child("used_date_time");
//            date_ser_ref.setValue(mydate);
//            DatabaseReference withdraw_amount_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_amount");
//            withdraw_amount_ser_ref.setValue(walletTV);
//            DatabaseReference withdraw_type_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_type");
//            withdraw_type_ser_ref.setValue("Tez Number - " + tezNumber);
//            DatabaseReference withdraw_time_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_time");
//            withdraw_time_ser_ref.setValue(mydate);
//            DatabaseReference withdraw_by_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_by");
//            withdraw_by_ser_ref.setValue(user.getPhoneNumber());
//            DatabaseReference withdraw_status_ser_ref = ref.child("withdraw").child(walletRefID).child("withdraw_refunded");
//            withdraw_status_ser_ref.setValue(false);
//            DatabaseReference walletAmount = ref.child("user").child(user.getPhoneNumber()).child("walletAmount");
//            int updated_wallet_amount = 0;
//            String final_wallet = String.valueOf(updated_wallet_amount);
//            walletAmount.setValue(final_wallet);
//            Intent intent = getIntent();
//            finish();
//            startActivity(intent);
//
//
//        } else {
//            Toast.makeText(this, "Enter Valid Tez number", Toast.LENGTH_SHORT).show();
//        }
//    }

    // function to generate a random string of length n
    static String getAlphaNumericString(int n) {

        // chose a Character random from this String
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                + "0123456789"
                + "abcdefghijklmnopqrstuvxyz";

        // create StringBuffer size of AlphaNumericString
        StringBuilder sb = new StringBuilder(n);

        for (int i = 0; i < n; i++) {

            // generate a random number between
            // 0 to AlphaNumericString variable length
            int index
                    = (int) (AlphaNumericString.length()
                    * Math.random());

            // add Character one by one in end of sb
            sb.append(AlphaNumericString
                    .charAt(index));
        }

        return sb.toString();
    }

    public void closeHelp(View view) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("Name", "used");
        editor.apply();
        dialog.dismiss();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.popup, menu);
        final MenuItem menuItem = menu.findItem(R.id.action_drawer_rupee);
        View actionView = MenuItemCompat.getActionView(menuItem);
        rupeevalue = (TextView) actionView.findViewById(R.id.rupee_badge);
        actionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOptionsItemSelected(menuItem);
            }
        });
        setupBadge();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case R.id.action_drawer_search:
                Toast.makeText(getApplicationContext(),"item clicked", Toast.LENGTH_LONG).show();
                return true;
            case R.id.action_drawer_rupee:
                Intent i1 = new Intent(HomeActivity.this, MyWalletTransaction.class);
                startActivity(i1);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void setupBadge() {
        if (rupeevalue != null) {
            if (rupees == 0) {
                if (rupeevalue.getVisibility() != View.GONE) {
                    rupeevalue.setVisibility(View.GONE);
                }
            } else {
                rupeevalue.setText(String.valueOf(rupees));
                if (rupeevalue.getVisibility() != View.VISIBLE) {
                    rupeevalue.setVisibility(View.VISIBLE);
                }
            }
        }
    }


}
